connect to CS257^

drop TRIGGER hw3.classcheck^
drop table hw3.schedule^
drop table hw3.class_prereq^
drop table hw3.class^
drop table hw3.student^

terminate^
